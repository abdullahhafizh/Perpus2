### HEAD

### 6.0.1

Fixes:

- Typo `kebab-veritcal` becomes `kebab-vertical`

### 6.0.0

Added:

- `kebab-horizontal` and `kebab-vertical` icons
- Polyfill for the `Object.assign` function

Removes:

- Removing a duplicate `ellipses` icon from the set. Use `ellipsis` instead.

### 5.0.1

Fixes:

- projects icon renders as a block, using `fill-rule` fixes it

### 5.0.0

Adds:

- `project`
- `note`
- `screen-full`
- `screen-normal`
- More node.js api endpoints for accessing icons https://github.com/primer/octicons/pull/120
- Creating a spritesheet demo https://github.com/primer/octicons/pull/121

Removes:

- Deprecating support for the webfont https://github.com/primer/octicons/pull/117
- Stop checking `/build/` directory into repository https://github.com/primer/octicons/pull/118
- Removing sass as a dependency https://github.com/primer/octicons/pull/119

### 4.4.0

Adds:

- svg.json file that is accessible from node require

### 4.3.0

Fixes:

- Vertical alignment on `italic`

Modifies:

- `person`
- `organization`

### 4.2.1

Fixes:

- Removing inline sourcemap from `min` versions of css.

### 4.2.0

Adds:

- Keywords.json file that has an index of all octicons with alias names

### 4.1.1 (June 16, 2016)

Fixes:

- Putting the `$octicons-font-path` back in the scss file.

### 4.1.0 (June 6, 2016)

Adds:

- Installation docs https://github.com/primer/octicons/pull/94
- `grabber`
- `plus-small`

Modifies:

- `smiley`

Refines:

- Renames `mail-reply` to `reply` and refines its shape.

Fixes:

- Revert license back to SPDX standard

### 4.0.0 (June 6, 2016)

Adds:

- Whole new grunt build system including svg sprite sheet.
- adding css min https://github.com/primer/octicons/pull/60
- adding woff2 format https://github.com/primer/octicons/issues/3
- creates spritesheet of svg files https://github.com/primer/octicons/issues/88

Removes:

- Bower support

Fixes:

- all svg icons include viewBox https://github.com/primer/octicons/issues/87
- license in package.json https://github.com/primer/octicons/issues/85

### 3.5.0 (February 12, 2016)

Adds:

- `unverified`

Refines:

- `verified`

### 3.4.1 (January 24, 2016)

This includes various SVG viewport refinements.

Refines:

- `thumbs-down`
- `logo-github`

### 3.4.0 (January 22, 2016)

Adds:

- `verified`
- `smiley`

Removes:

- `color-mode`

Refines:

- `primitive-dot`
- `horizontal-rule`
- `triangle-down`
- `triangle-up`
- `triangle-left`
- `triangle-right`
- `globe`
- `flame`
- `comment-discussion`

### 3.3.0 (November 12, 2015)

Adds:

- `logo-gist`

Resizes all our SVG to be 16x16 instead of 1024x1024

### 3.2.0 (November 6, 2015)

Adds:

- `bold`
- `text-size`
- `italic`
- `tasklist`

It also normalizes some styling in:

- `list-unordered`
- `list-ordered`
- `quote`
- `mention`
- `bookmark`
- `threebars`

Removes

- `screen-normal`
- `screen-full`


### 3.1.0 (August 13, 2015)

Adds

- `shield`

This thickens stroke widths slightly on the following icons:

- `circle-slash`
- `clock`
- `cloud-upload`
- `cloud-download`
- `dashboard`
- `info`
- `issue-closed`
- `issue`
- `issue-reopened`
- `history`
- `question`
- `search`

Fills `comment-discussion`

Thickens `x` to match `checkmark`

### 3.0.1 (August 10, 2015)

Some files were missing in `3.0.0`

### 3.0.0 (August 10, 2015)

Removes

- `microscope`
- `beer`
- `split`
- `puzzle`
- `steps`
- `podium`
- `timer`
- all `alignment` icons
- all `move` icons
- all `playback` icons
- all `jump` icons

Adds

- `beaker`
- `bell`
- `desktop-download`
- `watch`

Line-weight changes, sizing normalization, and new drawings

- `circle-slash`
- `lock`
- `cloud-upload`
- `cloud-download`
- `plus`
- `✕`
- `broadcast`
- `lock`
- all `repo` icons
- organization
- person
- all `chevrons` & `triangles`
- all `diff` icons
- `clippy`
- all `issue` and circular icons
- `rss`
- `ruby`
- `cancel`
- `settings`
- `mirror`
- `external-link`
- `history`
- `gear`
- `settings`
- `info`
- `history`
- `package`
- `gist-secret`
- `rocket`
- `law`
- `telescope`
- `search`
- `tag`
- `normal-screen`
- `iphone`
- `no-new-line`
- `desktop`
- all `git` icons
- `circuit-board`
- `heart`
- `home`
- `briefcase`
- `wiki`
- `bookmark`
- `briefcase`
- `calendar`
- `color-mode`
- `comment`
- `discussions`
- `credit-card`
- `dashboard`
- `camera`
- `video`
- `bug`
- `desktop`
- `ellipses`
- `eye`
- all `files` & `folders`
- `fold`
- `unfold`
- `gift`
- `graph`
- `hubot`
- `inbox`
- `jersey`
- `keyboard`
- `light-bulb`
- `link`
- `location`
- `mail`
- `mail-read`
- `marker`
- `plug`
- `mute`
- `pencil`
- `push-pin`
- `fullscreen`
- `unfullscreen`
- `server`
- `sign-in`
- `sign-out`
- `tag`
- `terminal`
- `thumbs-up`
- `thumbs-down`
- `trash`
- `unmute`
- `versions`
- `gist`
- `key`
- `megaphone`
- `checklist`

## 2.4.1 (June 2, 2015)

- Add the scss file I forgot to include

## 2.4.0 (June 2, 2015)

- Add `octicons.scss`
- Revert path changes to `sprockets-octicons.scss`, as they broke octicons in sprockets.

## 2.3.0 (May 28, 2015)

- Add a path variable to `sprockets-octicons.scss` to be consistent with octicons.less`

## 2.2.3 (May 21, 2015)

- Use SPDX license identifiers in package.json

## 2.2.2 (April 1, 2015)

Fixes file icons for

- `file-binary`
- `file-code`
- `file-media`
- `file-pdf`
- `file-symlink-file`
- `file-text`
- `file-zip`

## 2.2.1 (March 30, 2015)

- Fix vector artifact and smooth curves in `mark-github`

## 2.2.0 (Feb 18, 2015)

- Add two new icons: `thumbsup` and `thumbsdown`

## 2.0.1 (June 16, 2014)

- Add mention of github.com/logos to the license

## 2.0.0 (June 16, 2014)

- Hello world
