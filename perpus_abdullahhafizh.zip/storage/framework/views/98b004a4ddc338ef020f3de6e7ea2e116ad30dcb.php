<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Styles -->    
    <?php echo $__env->yieldContent('head-content'); ?>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">    
</head>
<body>
    <div id="app">
        <?php if(auth()->guard()->guest()): ?>
        <nav class="navbar navbar-expand-md navbar-light navbar-laravel">
            <?php else: ?>
            <?php if(Auth::user()->status==1): ?>
            <nav class="navbar navbar-expand-md navbar-dark bg-dark navbar-laravel">
                <?php else: ?>
                <nav class="navbar navbar-expand-md navbar-light navbar-laravel" style="background-color: #e3f2fd;">
                    <?php endif; ?>
                    <?php endif; ?>
                    <div class="container">
                        <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                            <?php echo e(config('app.name', 'Laravel')); ?>

                        </a>
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>

                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <!-- Left Side Of Navbar -->
                            <ul class="navbar-nav mr-auto">

                            </ul>

                            <!-- Right Side Of Navbar -->
                            <ul class="navbar-nav ml-auto">
                                <!-- Authentication Links -->
                                <?php if(auth()->guard()->guest()): ?>
                                <li><a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a></li>
                                <li><a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a></li>
                                <?php else: ?>
                                <li><a class="nav-link" href="<?php echo e(url('admin/peminjaman')); ?>"><?php echo e(__('Peminjaman')); ?></a></li>
                                <li><a class="nav-link" href="<?php echo e(url('admin/pengembalian')); ?>"><?php echo e(__('Pengembalian')); ?></a></li>
                                <li><a class="nav-link" href="<?php echo e(url('admin/stok')); ?>"><?php echo e(__('Stok')); ?></a></li>
                                <li><a class="nav-link" href="<?php echo e(url('admin/buku')); ?>"><?php echo e(__('Buku')); ?></a></li>
                                <li><a class="nav-link" href="<?php echo e(url('admin/user')); ?>"><?php echo e(__('User')); ?></a></li>
                                <li class="nav-item dropdown">
                                    <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                        <?php echo e(Auth::user()->username); ?> <span class="caret"></span>
                                    </a>

                                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                        onclick="event.preventDefault();
                                        document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </nav>

            <main class="py-4">
                <?php echo $__env->yieldContent('content'); ?>
            </main>
        </div>

        <!-- Scripts -->
        <script src="<?php echo e(asset('js/app.js')); ?>"></script>        
        <?php echo $__env->yieldContent('foot-content'); ?>
    </body>
    </html>
