<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card border-light">
                <div class="card-header">Buku</div>

                <div class="card-body">
                    <div class="form-group">
                        <a href="<?php echo e(url('admin/buku/create')); ?>" style="color: inherit;text-decoration: none;"><button type="button" class="btn btn-success btn-lg btn-block">Input Buku</button></a>
                    </div>
                    <div class="table-responsive">
                        <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                    <th>Kode</th>
                                    <th>Judul</th>
                                    <th>Pengarang</th>
                                    <th>Kategori</th>
                                    <th>Option</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th>Kode</th>
                                    <th>Judul</th>
                                    <th>Pengarang</th>
                                    <th>Kategori</th>
                                    <th>Option</th>
                                </tr>
                            </tfoot>  
                            <tbody>
                                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($book->kode_buku); ?></td>
                                    <td><?php echo e($book->judul_buku); ?></td>
                                    <td><?php echo e($book->pengarang); ?></td>
                                    <td><?php echo e($book->kategori); ?></td>
                                    <td>
                                        <div class="text-center">
                                            <div class="btn-group btn-group-toggle" data-toggle="buttons">
                                                <button type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target=".up<?php echo e($book->id); ?>">Edit</button>
                                                <button type="button" class="btn btn-sm btn-danger" data-toggle="modal" data-target=".<?php echo e($book->id); ?>">Hapus</button>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade up<?php echo e($book->id); ?>" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Edit <?php echo e($book->judul_buku); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form method="POST" action="<?php echo e(url('admin/buku/'.$book->id.'/update')); ?>">
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">                        
                        <label for="kode_buku" class="col-form-label"><?php echo e(__('Kode Buku')); ?></label>

                        <input id="kode_buku" type="text" class="form-control<?php echo e($errors->has('kode_buku') ? ' is-invalid' : ''); ?>" name="kode_buku" value="<?php echo e($book->kode_buku); ?>" required>


                        <?php if($errors->has('kode_buku')): ?>
                        <span class="invalid-feedback">
                            <strong><?php echo e($errors->first('kode_buku')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">                        
                        <label for="judul_buku" class="col-form-label"><?php echo e(__('Judul Buku')); ?></label>

                        <input id="judul_buku" type="text" class="form-control<?php echo e($errors->has('judul_buku') ? ' is-invalid' : ''); ?>" name="judul_buku" value="<?php echo e($book->judul_buku); ?>" required>


                        <?php if($errors->has('judul_buku')): ?>
                        <span class="invalid-feedback">
                            <strong><?php echo e($errors->first('judul_buku')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">                        
                        <label for="pengarang" class="col-form-label"><?php echo e(__('Pengarang')); ?></label>

                        <input id="pengarang" type="text" class="form-control<?php echo e($errors->has('pengarang') ? ' is-invalid' : ''); ?>" name="pengarang" value="<?php echo e($book->pengarang); ?>" required>


                        <?php if($errors->has('pengarang')): ?>
                        <span class="invalid-feedback">
                            <strong><?php echo e($errors->first('pengarang')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">                        
                        <label for="kategori" class="col-form-label"><?php echo e(__('Kategori')); ?></label>

                        <input id="kategori" type="text" class="form-control<?php echo e($errors->has('kategori') ? ' is-invalid' : ''); ?>" name="kategori" value="<?php echo e($book->kategori); ?>" required>


                        <?php if($errors->has('kategori')): ?>
                        <span class="invalid-feedback">
                            <strong><?php echo e($errors->first('kategori')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-success">Simpan</button>                
                </div>
            </form>            
        </div>
    </div>
</div>
<div class="modal fade <?php echo e($book->id); ?>" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-sm">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Buku yang akan dihapus tidak dapat dikembalikan!</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Yakin Ingin menghapus <?php echo e($book->judul_buku); ?>?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-warning" data-dismiss="modal">Batal</button>
                <a href="<?php echo e(url('admin/buku/'.$book->id.'/destroy')); ?>" class="btn btn-danger">Hapus</a>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('akin.dtScript', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>