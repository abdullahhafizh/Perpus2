<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card border-light">
                <div class="card-header"><?php echo e(__('Form Input Buku')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(url('admin/buku/create')); ?>">
                        <?php echo csrf_field(); ?>                        

                        <div class="form-group row">
                            <label for="kode_buku" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Kode Buku')); ?></label>

                            <div class="col-md-6">
                                <input id="kode_buku" type="text" class="form-control<?php echo e($errors->has('kode_buku') ? ' is-invalid' : ''); ?>" name="kode_buku" value="<?php echo e(old('kode_buku')); ?>" required>

                                <?php if($errors->has('kode_buku')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('kode_buku')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="judul_buku" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Judul Buku')); ?></label>

                            <div class="col-md-6">
                                <input id="judul_buku" type="text" class="form-control<?php echo e($errors->has('judul_buku') ? ' is-invalid' : ''); ?>" name="judul_buku" value="<?php echo e(old('judul_buku')); ?>" required>

                                <?php if($errors->has('judul_buku')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('judul_buku')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="pengarang" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Pengarang')); ?></label>

                            <div class="col-md-6">
                                <input id="pengarang" type="text" class="form-control<?php echo e($errors->has('pengarang') ? ' is-invalid' : ''); ?>" name="pengarang" value="<?php echo e(old('pengarang')); ?>" required>

                                <?php if($errors->has('pengarang')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('pengarang')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="kategori" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Kategori')); ?></label>

                            <div class="col-md-6">
                                <input id="kategori" type="text" class="form-control<?php echo e($errors->has('kategori') ? ' is-invalid' : ''); ?>" name="kategori" value="<?php echo e(old('kategori')); ?>" required>

                                <?php if($errors->has('kategori')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('kategori')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>                        

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Simpan')); ?>

                                </button>
                                <a href="<?php echo e(url('admin/buku')); ?>" class="btn btn-danger">Batal</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>