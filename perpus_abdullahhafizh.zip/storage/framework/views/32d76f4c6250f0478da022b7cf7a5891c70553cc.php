<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card border-light">
                <div class="card-header">Peminjaman</div>

                <div class="card-body">                    
                    <div class="table-responsive">
                        <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Nama</th>
                                    <th>Alamat</th>
                                    <th>Judul Buku</th>
                                    <th>Tanggal Pinjam</th>
                                    <th>Option</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th>ID</th>
                                    <th>Nama</th>
                                    <th>Alamat</th>
                                    <th>Judul Buku</th>
                                    <th>Tanggal Pinjam</th>
                                    <th>Option</th>
                                </tr>
                            </tfoot>  
                            <tbody>
                                <?php $__currentLoopData = $borrows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $borrow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($borrow->id); ?></td>
                                    <td><?php echo e($borrow->nama_peminjam); ?></td>
                                    <td><?php echo e($borrow->alamat_peminjam); ?></td>
                                    <td><?php echo e($borrow->judul_buku); ?></td>
                                    <td><?php echo e($borrow->tanggal_pinjam); ?></td>
                                    <td>
                                        <div class="text-center">
                                            <a href="<?php echo e(url('admin/peminjaman/'.$borrow->id.'/store')); ?>" class="btn btn-sm btn-warning">Kembalikan</a>                    
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('akin.dtScript', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>