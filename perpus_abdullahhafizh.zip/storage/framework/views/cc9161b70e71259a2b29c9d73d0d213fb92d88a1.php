<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Input Stok Buku')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(url('admin/stok/create')); ?>">
                        <?php echo csrf_field(); ?>                        

                        <div class="form-group row">
                            <label for="judul_buku" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nama Buku')); ?></label>

                            <div class="col-md-6">
                                <input id="judul_buku" type="text" class="form-control<?php echo e($errors->has('judul_buku') ? ' is-invalid' : ''); ?>" name="judul_buku" list="listbuku" value="<?php echo e(old('judul_buku')); ?>" required>
                                <datalist id="listbuku">
                                    <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option><?php echo e($book->judul_buku); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </datalist>

                                <?php if($errors->has('judul_buku')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('judul_buku')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="nomor_rak" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nomor Rak')); ?></label>

                            <div class="col-md-6">
                                <input id="nomor_rak" type="number" class="form-control<?php echo e($errors->has('nomor_rak') ? ' is-invalid' : ''); ?>" name="nomor_rak" value="<?php echo e(old('nomor_rak')); ?>" required>

                                <?php if($errors->has('nomor_rak')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('nomor_rak')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="jumlah_buku" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Jumlah Buku')); ?></label>

                            <div class="col-md-6">
                                <input id="jumlah_buku" type="number" class="form-control<?php echo e($errors->has('jumlah_buku') ? ' is-invalid' : ''); ?>" name="jumlah_buku" value="<?php echo e(old('jumlah_buku')); ?>" required>

                                <?php if($errors->has('jumlah_buku')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('jumlah_buku')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Simpan')); ?>

                                </button>
                                <a href="<?php echo e(url('admin/buku')); ?>" class="btn btn-danger">Batal</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>