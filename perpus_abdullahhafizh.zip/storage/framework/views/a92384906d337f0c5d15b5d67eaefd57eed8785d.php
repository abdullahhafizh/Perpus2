<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card border-light">
                <div class="card-header">User</div>

                <div class="card-body">
                    <div class="form-group">
                        <a href="<?php echo e(route('register')); ?>" style="color: inherit;text-decoration: none;"><button type="button" class="btn btn-success btn-lg btn-block">Input User</button></a>
                    </div>
                    <div class="table-responsive">
                        <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Username</th>
                                    <th>Hak Akses</th>
                                    <th>Option</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th>ID</th>
                                    <th>Username</th>
                                    <th>Hak Akses</th>
                                    <th>Option</th>
                                </tr>
                            </tfoot>  
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($user->id); ?></td>
                                    <td><?php echo e($user->username); ?></td>
                                    <?php if($user->status==1): ?>
                                    <td>Administrator</td>
                                    <?php else: ?>
                                    <td>User Biasa</td>
                                    <?php endif; ?>
                                    <td>
                                        <div class="text-center">
                                            <div class="btn-group btn-group-toggle" data-toggle="buttons">
                                                <button type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target=".up<?php echo e($user->id); ?>">Edit Hak Akses</button>
                                                <button type="button" class="btn btn-sm btn-danger" data-toggle="modal" data-target=".del<?php echo e($user->id); ?>">Hapus</button>
                                            </div>
                                        </div>                       
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade up<?php echo e($user->id); ?>" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Edit Hak Akses <?php echo e($user->username); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form method="POST" action="<?php echo e(url('admin/user/'.$user->id.'/update')); ?>">
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">                        
                        <label for="status" class="col-form-label"><?php echo e(__('Hak Akses')); ?></label>

                        <select id="status" class="form-control<?php echo e($errors->has('status') ? ' is-invalid' : ''); ?>" name="status" required>
                            <option value="0" <?php echo e($user->status == 0 ? 'selected' : null); ?>>User Biasa</option>
                            <option value="1" <?php echo e($user->status == 1 ? 'selected' : null); ?>>Administrator</option>
                        </select>

                        <?php if($errors->has('status')): ?>
                        <span class="invalid-feedback">
                            <strong><?php echo e($errors->first('status')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-success">Simpan</button>                
                </div>
            </form>            
        </div>
    </div>
</div>
<div class="modal fade del<?php echo e($user->id); ?>" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-sm">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Menghapus <?php echo e($user->username); ?>...</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Yakin Ingin menghapus user <?php echo e($user->username); ?>?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-warning" data-dismiss="modal">Batal</button>
                <a href="<?php echo e(url('admin/user/'.$user->id.'/destroy')); ?>" class="btn btn-danger">Hapus</a>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('akin.dtScript', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>