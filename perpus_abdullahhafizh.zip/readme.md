## Cara Install

- Buat database "perpus_abdullahhafizh" (tanpa kutip)
- Atur username dan password mysql di file .env
  Atur username di :
  DB_USERNAME=nama_username
  Atur password di :
  DB_PASSWORD=passwordnya
- Lalu buka directory project di cmd/terminal
- Ketik "php artisan migrate" (tanpa kutip)
- Lalu ketik "php artisan ser" (tanpa kutip)
